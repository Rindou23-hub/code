// ============================================================
// FILE: main.dart
// FUNGSI: Entry point dan seluruh logika UI aplikasi
// ============================================================

import 'dart:convert'; // untuk jsonEncode / jsonDecode
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart'; // untuk format tanggal
import 'package:shared_preferences/shared_preferences.dart';
import 'task_model.dart';

// ── ENTRY POINT ──────────────────────────────────────────────
void main() async {
  WidgetsFlutterBinding.ensureInitialized(); // wajib sebelum async di main
  await initializeDateFormatting('id', null); // inisialisasi locale Indonesia
  runApp(const StudentTaskManagerApp());
}

// ── ROOT WIDGET ──────────────────────────────────────────────
class StudentTaskManagerApp extends StatelessWidget {
  const StudentTaskManagerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student Task Manager',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4F46E5), // Indigo
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        cardTheme: CardThemeData(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 12,
          ),
        ),
      ),
      home: const TaskListScreen(),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// SCREEN UTAMA — TaskListScreen
// StatefulWidget karena data bisa berubah (tambah/edit/hapus tugas)
// ═══════════════════════════════════════════════════════════════
class TaskListScreen extends StatefulWidget {
  const TaskListScreen({super.key});

  @override
  State<TaskListScreen> createState() => _TaskListScreenState();
}

class _TaskListScreenState extends State<TaskListScreen> {
  // ── STATE VARIABLES ────────────────────────────────────────
  List<TaskModel> _allTasks = []; // semua tugas (sumber kebenaran)
  List<TaskModel> _filteredTasks = []; // tugas setelah filter & search
  String _searchQuery = ''; // teks pencarian
  String _filterStatus = 'Semua'; // filter status aktif
  final TextEditingController _searchController = TextEditingController();

  // Kunci SharedPreferences untuk menyimpan list tugas
  static const String _storageKey = 'tasks_data';

  // ── LIFECYCLE ──────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _loadTasksFromStorage(); // muat data saat aplikasi dibuka
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // ══════════════════════════════════════════════════════════
  // SHARED PREFERENCES — SIMPAN & MUAT DATA
  // ══════════════════════════════════════════════════════════

  /// Memuat semua tugas dari SharedPreferences
  Future<void> _loadTasksFromStorage() async {
    final prefs = await SharedPreferences.getInstance();
    final String? jsonString = prefs.getString(_storageKey);

    if (jsonString != null) {
      // Decode JSON string → List<dynamic> → List<TaskModel>
      final List<dynamic> jsonList = jsonDecode(jsonString);
      setState(() {
        _allTasks = jsonList
            .map((item) => TaskModel.fromMap(Map<String, dynamic>.from(item)))
            .toList();
      });
    }
    _applyFilterAndSearch(); // terapkan filter setelah data dimuat
  }

  /// Menyimpan semua tugas ke SharedPreferences
  Future<void> _saveTasksToStorage() async {
    final prefs = await SharedPreferences.getInstance();
    // Encode List<TaskModel> → List<Map> → JSON String
    final String jsonString = jsonEncode(
      _allTasks.map((task) => task.toMap()).toList(),
    );
    await prefs.setString(_storageKey, jsonString);
  }

  // ══════════════════════════════════════════════════════════
  // FILTER & SEARCH
  // ══════════════════════════════════════════════════════════

  /// Menerapkan filter status dan pencarian teks sekaligus
  void _applyFilterAndSearch() {
    setState(() {
      _filteredTasks = _allTasks.where((task) {
        // 1) Filter berdasarkan status
        final bool matchStatus = switch (_filterStatus) {
          'Belum Selesai' => !task.isCompleted,
          'Sudah Selesai' => task.isCompleted,
          _ => true, // 'Semua'
        };

        // 2) Filter berdasarkan pencarian (judul ATAU mata kuliah)
        final bool matchSearch =
            _searchQuery.isEmpty ||
            task.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            task.course.toLowerCase().contains(_searchQuery.toLowerCase());

        return matchStatus && matchSearch;
      }).toList();
    });
  }

  /// Dipanggil saat teks search berubah
  void _onSearchChanged(String value) {
    _searchQuery = value;
    _applyFilterAndSearch();
  }

  /// Dipanggil saat filter status berubah
  void _onFilterChanged(String status) {
    _filterStatus = status;
    _applyFilterAndSearch();
  }

  // ══════════════════════════════════════════════════════════
  // CRUD — CREATE, READ, UPDATE, DELETE
  // ══════════════════════════════════════════════════════════

  /// Menambahkan tugas baru ke list
  void _addTask(TaskModel task) {
    setState(() {
      _allTasks.add(task);
    });
    _saveTasksToStorage();
    _applyFilterAndSearch();
  }

  /// Mengupdate tugas yang sudah ada berdasarkan ID
  void _updateTask(TaskModel updatedTask) {
    setState(() {
      final index = _allTasks.indexWhere((t) => t.id == updatedTask.id);
      if (index != -1) _allTasks[index] = updatedTask;
    });
    _saveTasksToStorage();
    _applyFilterAndSearch();
  }

  /// Menghapus tugas berdasarkan ID
  void _deleteTask(int id) {
    setState(() {
      _allTasks.removeWhere((t) => t.id == id);
    });
    _saveTasksToStorage();
    _applyFilterAndSearch();
  }

  /// Toggle status selesai/belum selesai
  void _toggleComplete(TaskModel task) {
    _updateTask(task.copyWith(isCompleted: !task.isCompleted));
  }

  /// Membuat ID unik berdasarkan timestamp
  int _generateId() => DateTime.now().millisecondsSinceEpoch;

  // ══════════════════════════════════════════════════════════
  // DIALOG — TAMBAH & EDIT TUGAS
  // ══════════════════════════════════════════════════════════

  /// Membuka dialog form untuk tambah atau edit tugas
  void _showTaskDialog({TaskModel? existingTask}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => TaskFormDialog(
        existingTask: existingTask,
        onSave: (task) {
          if (existingTask == null) {
            // Mode tambah: assign ID baru
            _addTask(task.copyWith(id: _generateId()));
          } else {
            // Mode edit: pertahankan ID lama
            _updateTask(task);
          }
        },
      ),
    );
  }

  /// Dialog konfirmasi sebelum menghapus tugas
  void _showDeleteConfirmation(TaskModel task) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus Tugas?'),
        content: Text(
          'Yakin ingin menghapus tugas "${task.title}"? '
          'Tindakan ini tidak dapat dibatalkan.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx), // batal
            child: const Text('Batal'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              Navigator.pop(ctx);
              _deleteTask(task.id);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Tugas "${task.title}" dihapus'),
                  behavior: SnackBarBehavior.floating,
                ),
              );
            },
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════════
  // STATISTIK
  // ══════════════════════════════════════════════════════════

  int get _totalTasks => _allTasks.length;
  int get _completedTasks => _allTasks.where((t) => t.isCompleted).length;
  int get _pendingTasks => _totalTasks - _completedTasks;

  // ══════════════════════════════════════════════════════════
  // BUILD — UI UTAMA
  // ══════════════════════════════════════════════════════════

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surfaceContainerLow,

      // ── APP BAR ─────────────────────────────────────────
      appBar: AppBar(
        backgroundColor: colorScheme.primary,
        foregroundColor: colorScheme.onPrimary,
        title: const Text(
          'Student Task Manager',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
        ),
        centerTitle: false,
        elevation: 0,
      ),

      // ── BODY ────────────────────────────────────────────
      body: Column(
        children: [
          // 1) Kartu statistik di atas
          _buildStatisticsCard(colorScheme),

          // 2) Search bar
          _buildSearchBar(),

          // 3) Filter chip (Semua / Belum Selesai / Sudah Selesai)
          _buildFilterChips(),

          // 4) List tugas
          Expanded(child: _buildTaskList()),
        ],
      ),

      // ── FAB — tombol tambah tugas ───────────────────────
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showTaskDialog(),
        icon: const Icon(Icons.add),
        label: const Text('Tambah Tugas'),
        backgroundColor: colorScheme.primary,
        foregroundColor: colorScheme.onPrimary,
      ),
    );
  }

  // ── WIDGET: Kartu Statistik ──────────────────────────────
  Widget _buildStatisticsCard(ColorScheme cs) {
    return Container(
      color: cs.primary,
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
      child: Row(
        children: [
          _buildStatItem('Total', _totalTasks, Icons.assignment, cs),
          const SizedBox(width: 12),
          _buildStatItem('Selesai', _completedTasks, Icons.check_circle, cs),
          const SizedBox(width: 12),
          _buildStatItem('Pending', _pendingTasks, Icons.pending_actions, cs),
        ],
      ),
    );
  }

  Widget _buildStatItem(
    String label,
    int count,
    IconData icon,
    ColorScheme cs,
  ) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: cs.onPrimary.withOpacity(0.15),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          children: [
            Icon(icon, color: cs.onPrimary, size: 22),
            const SizedBox(height: 4),
            Text(
              '$count',
              style: TextStyle(
                color: cs.onPrimary,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                color: cs.onPrimary.withOpacity(0.85),
                fontSize: 11,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── WIDGET: Search Bar ───────────────────────────────────
  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: TextField(
        controller: _searchController,
        onChanged: _onSearchChanged,
        decoration: InputDecoration(
          hintText: 'Cari tugas atau mata kuliah...',
          prefixIcon: const Icon(Icons.search),
          suffixIcon: _searchQuery.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    _searchController.clear();
                    _onSearchChanged('');
                  },
                )
              : null,
          filled: true,
          fillColor: Colors.white,
        ),
      ),
    );
  }

  // ── WIDGET: Filter Chips ─────────────────────────────────
  Widget _buildFilterChips() {
    const filters = ['Semua', 'Belum Selesai', 'Sudah Selesai'];
    return SizedBox(
      height: 44,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: filters.length,
        itemBuilder: (_, index) {
          final filter = filters[index];
          final isActive = _filterStatus == filter;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: FilterChip(
              label: Text(filter),
              selected: isActive,
              onSelected: (_) => _onFilterChanged(filter),
              selectedColor: Theme.of(context).colorScheme.primaryContainer,
            ),
          );
        },
      ),
    );
  }

  // ── WIDGET: ListView Tugas ───────────────────────────────
  // Menggunakan ListView.builder agar hanya item yang terlihat
  // yang dirender (hemat memori untuk list panjang)
  Widget _buildTaskList() {
    if (_filteredTasks.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inbox_outlined, size: 64, color: Colors.grey.shade400),
            const SizedBox(height: 12),
            Text(
              _allTasks.isEmpty
                  ? 'Belum ada tugas.\nTambahkan tugas pertamamu!'
                  : 'Tidak ada tugas yang sesuai.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey.shade600, fontSize: 16),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 90),
      itemCount: _filteredTasks.length,
      // itemBuilder dipanggil hanya untuk item yang tampil di layar
      itemBuilder: (context, index) {
        final task = _filteredTasks[index];
        return _buildTaskCard(task);
      },
    );
  }

  // ── WIDGET: Kartu Tugas ──────────────────────────────────
  Widget _buildTaskCard(TaskModel task) {
    final priorityColor = _getPriorityColor(task.priority);
    final isOverdue =
        !task.isCompleted && task.deadline.isBefore(DateTime.now());

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _showTaskDialog(existingTask: task), // tap = edit
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Checkbox status selesai
              Checkbox(
                value: task.isCompleted,
                onChanged: (_) => _toggleComplete(task),
                activeColor: Colors.green,
              ),

              // Konten utama
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Judul tugas
                    Text(
                      task.title,
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        decoration: task.isCompleted
                            ? TextDecoration.lineThrough
                            : null,
                        color: task.isCompleted ? Colors.grey : Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 4),

                    // Mata kuliah
                    Row(
                      children: [
                        const Icon(
                          Icons.school_outlined,
                          size: 13,
                          color: Colors.blueGrey,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          task.course,
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.blueGrey,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),

                    // Baris bawah: deadline + prioritas + status
                    Row(
                      children: [
                        // Deadline
                        Icon(
                          Icons.calendar_today_outlined,
                          size: 12,
                          color: isOverdue ? Colors.red : Colors.grey,
                        ),
                        const SizedBox(width: 3),
                        Text(
                          DateFormat('dd MMM yyyy', 'id').format(task.deadline),
                          style: TextStyle(
                            fontSize: 11,
                            color: isOverdue ? Colors.red : Colors.grey,
                            fontWeight: isOverdue
                                ? FontWeight.bold
                                : FontWeight.normal,
                          ),
                        ),
                        if (isOverdue) ...[
                          const SizedBox(width: 4),
                          const Text(
                            '⚠ Terlambat',
                            style: TextStyle(fontSize: 10, color: Colors.red),
                          ),
                        ],
                        const Spacer(),

                        // Badge prioritas
                        _buildPriorityBadge(task.priority, priorityColor),
                      ],
                    ),
                  ],
                ),
              ),

              // Tombol hapus
              IconButton(
                icon: const Icon(Icons.delete_outline, color: Colors.red),
                onPressed: () => _showDeleteConfirmation(task),
                tooltip: 'Hapus tugas',
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── HELPER: Badge prioritas berwarna ────────────────────
  Widget _buildPriorityBadge(String priority, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color, width: 1),
      ),
      child: Text(
        priority,
        style: TextStyle(
          fontSize: 10,
          color: color,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  // ── HELPER: Warna prioritas ──────────────────────────────
  Color _getPriorityColor(String priority) {
    return switch (priority) {
      'Tinggi' => Colors.red, // merah = urgen
      'Rendah' => Colors.green, // hijau = santai
      _ => Colors.orange, // oranye = sedang (default)
    };
  }
}

// ═══════════════════════════════════════════════════════════════
// DIALOG FORM — TaskFormDialog
// Digunakan untuk menambah tugas baru DAN mengedit tugas yang ada
// ═══════════════════════════════════════════════════════════════
class TaskFormDialog extends StatefulWidget {
  final TaskModel? existingTask; // null = mode tambah, ada isi = mode edit
  final void Function(TaskModel) onSave;

  const TaskFormDialog({super.key, this.existingTask, required this.onSave});

  @override
  State<TaskFormDialog> createState() => _TaskFormDialogState();
}

class _TaskFormDialogState extends State<TaskFormDialog> {
  // Form key untuk validasi
  final _formKey = GlobalKey<FormState>();

  // Controller untuk setiap field teks
  late final TextEditingController _titleController;
  late final TextEditingController _courseController;
  late final TextEditingController _descController;

  // State untuk pilihan yang bukan teks bebas
  DateTime? _selectedDeadline;
  String _selectedPriority = 'Sedang';

  final List<String> _priorities = ['Tinggi', 'Sedang', 'Rendah'];

  // ── LIFECYCLE ────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    // Jika mode edit, isi form dengan data tugas yang sudah ada
    final task = widget.existingTask;
    _titleController = TextEditingController(text: task?.title ?? '');
    _courseController = TextEditingController(text: task?.course ?? '');
    _descController = TextEditingController(text: task?.description ?? '');
    _selectedDeadline = task?.deadline;
    _selectedPriority = task?.priority ?? 'Sedang';
  }

  @override
  void dispose() {
    _titleController.dispose();
    _courseController.dispose();
    _descController.dispose();
    super.dispose();
  }

  // ── DATE PICKER ──────────────────────────────────────────
  Future<void> _pickDeadline() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDeadline ?? now,
      firstDate: now.subtract(const Duration(days: 365)), // boleh tanggal lalu
      lastDate: now.add(const Duration(days: 365 * 2)),
    );
    if (picked != null) {
      setState(() => _selectedDeadline = picked);
    }
  }

  // ── SIMPAN ───────────────────────────────────────────────
  void _handleSave() {
    // Validasi form (judul & mata kuliah tidak boleh kosong)
    if (!_formKey.currentState!.validate()) return;

    // Validasi deadline (wajib dipilih)
    if (_selectedDeadline == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Deadline wajib dipilih!'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    // Buat objek TaskModel dari input form
    final task = TaskModel(
      id: widget.existingTask?.id ?? 0, // ID akan di-generate di parent
      title: _titleController.text.trim(),
      course: _courseController.text.trim(),
      description: _descController.text.trim(),
      deadline: _selectedDeadline!,
      priority: _selectedPriority,
      isCompleted: widget.existingTask?.isCompleted ?? false,
    );

    Navigator.pop(context); // tutup dialog
    widget.onSave(task); // kirim data ke parent
  }

  // ── BUILD ────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existingTask != null;

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              // Header dialog
              Row(
                children: [
                  Icon(
                    isEdit ? Icons.edit_note : Icons.add_task,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    isEdit ? 'Edit Tugas' : 'Tambah Tugas Baru',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const Divider(height: 24),

              // ── Field: Judul Tugas ──────────────────────
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: 'Judul Tugas *',
                  hintText: 'Contoh: Laporan Praktikum Fisika',
                  prefixIcon: Icon(Icons.title),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Judul tugas tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 14),

              // ── Field: Mata Kuliah ──────────────────────
              TextFormField(
                controller: _courseController,
                decoration: const InputDecoration(
                  labelText: 'Mata Kuliah *',
                  hintText: 'Contoh: Pemrograman Mobile',
                  prefixIcon: Icon(Icons.school),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Mata kuliah tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 14),

              // ── Field: Deskripsi ────────────────────────
              TextFormField(
                controller: _descController,
                decoration: const InputDecoration(
                  labelText: 'Deskripsi',
                  hintText: 'Detail atau catatan tambahan...',
                  prefixIcon: Icon(Icons.description),
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 14),

              // ── Field: Deadline (DatePicker) ────────────
              GestureDetector(
                onTap: _pickDeadline,
                child: InputDecorator(
                  decoration: InputDecoration(
                    labelText: 'Deadline *',
                    prefixIcon: const Icon(Icons.calendar_today),
                    suffixIcon: const Icon(Icons.arrow_drop_down),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: Text(
                    _selectedDeadline == null
                        ? 'Pilih tanggal deadline...'
                        : DateFormat(
                            'EEEE, dd MMMM yyyy',
                            'id',
                          ).format(_selectedDeadline!),
                    style: TextStyle(
                      color: _selectedDeadline == null
                          ? Colors.grey
                          : Colors.black87,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 14),

              // ── Field: Prioritas (Dropdown) ─────────────
              DropdownButtonFormField<String>(
                value: _selectedPriority,
                decoration: const InputDecoration(
                  labelText: 'Prioritas',
                  prefixIcon: Icon(Icons.flag),
                ),
                items: _priorities
                    .map(
                      (p) => DropdownMenuItem(
                        value: p,
                        child: Row(
                          children: [
                            Container(
                              width: 10,
                              height: 10,
                              margin: const EdgeInsets.only(right: 8),
                              decoration: BoxDecoration(
                                color: _priorityColorFor(p),
                                shape: BoxShape.circle,
                              ),
                            ),
                            Text(p),
                          ],
                        ),
                      ),
                    )
                    .toList(),
                onChanged: (value) =>
                    setState(() => _selectedPriority = value!),
              ),
              const SizedBox(height: 24),

              // ── Tombol Aksi ─────────────────────────────
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Batal'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: _handleSave,
                      icon: Icon(isEdit ? Icons.save : Icons.add),
                      label: Text(isEdit ? 'Simpan' : 'Tambah'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── HELPER: warna prioritas dalam dropdown ───────────────
  Color _priorityColorFor(String priority) {
    return switch (priority) {
      'Tinggi' => Colors.red,
      'Rendah' => Colors.green,
      _ => Colors.orange,
    };
  }
}
