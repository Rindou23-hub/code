// ============================================================
// FILE: task_model.dart
// FUNGSI: Mendefinisikan struktur data tugas (Task)
// ============================================================

class TaskModel {
  // ── ATRIBUT ──────────────────────────────────────────────
  int id;             // ID unik setiap tugas
  String title;       // Judul tugas
  String description; // Deskripsi tugas
  String course;      // Nama mata kuliah
  DateTime deadline;  // Batas waktu pengumpulan
  bool isCompleted;   // Status selesai/belum
  String priority;    // Prioritas: 'Tinggi', 'Sedang', 'Rendah'

  // ── CONSTRUCTOR ──────────────────────────────────────────
  TaskModel({
    required this.id,
    required this.title,
    required this.description,
    required this.course,
    required this.deadline,
    this.isCompleted = false,         // default: belum selesai
    this.priority = 'Sedang',         // default: prioritas sedang
  });

  // ── toMap() ──────────────────────────────────────────────
  // Mengubah objek TaskModel → Map<String, dynamic>
  // Digunakan saat menyimpan ke SharedPreferences (harus jadi String/JSON)
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'course': course,
      'deadline': deadline.toIso8601String(), // DateTime → String ISO 8601
      'isCompleted': isCompleted ? 1 : 0,     // bool → int (0/1)
      'priority': priority,
    };
  }

  // ── fromMap() ────────────────────────────────────────────
  // Factory constructor: mengubah Map → objek TaskModel
  // Digunakan saat memuat data dari SharedPreferences
  factory TaskModel.fromMap(Map<String, dynamic> map) {
    return TaskModel(
      id: map['id'] as int,
      title: map['title'] as String,
      description: map['description'] as String,
      course: map['course'] as String,
      deadline: DateTime.parse(map['deadline'] as String), // String → DateTime
      isCompleted: (map['isCompleted'] as int) == 1,        // int → bool
      priority: map['priority'] as String,
    );
  }

  // ── copyWith() ───────────────────────────────────────────
  // Helper untuk membuat salinan objek dengan sebagian atribut diubah
  // Berguna saat mengedit tugas
  TaskModel copyWith({
    int? id,
    String? title,
    String? description,
    String? course,
    DateTime? deadline,
    bool? isCompleted,
    String? priority,
  }) {
    return TaskModel(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      course: course ?? this.course,
      deadline: deadline ?? this.deadline,
      isCompleted: isCompleted ?? this.isCompleted,
      priority: priority ?? this.priority,
    );
  }
}