import 'package:flutter/material.dart';
import 'item_model.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aplikasi List Item',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: ItemListPage(),
    );
  }
}

class ItemListPage extends StatefulWidget {
  const ItemListPage({super.key});

  @override
  State<ItemListPage> createState() => _ItemListPageState();
}

class _ItemListPageState extends State<ItemListPage> {
  List<ItemModel> _items = [];
  List<ItemModel> _filteredItems = [];                          // [BARU] List hasil filter pencarian
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descController = TextEditingController();
  final TextEditingController _searchController = TextEditingController(); // [BARU] Controller search

  final List<ItemModel> _dummyItems = [
    ItemModel(id: 1, name: 'Laptop', description: 'Laptop gaming'),
    ItemModel(id: 2, name: 'Mouse', description: 'Mouse Wireless'),
    ItemModel(id: 3, name: 'Keyboard', description: 'Keyboard mechanical'),
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
    // [BARU] Listener agar list otomatis filter saat teks search berubah
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descController.dispose();
    _searchController.dispose(); // [BARU] Dispose controller search
    super.dispose();
  }

  // [BARU] Fungsi filter item berdasarkan query pencarian
  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      if (query.isEmpty) {
        _filteredItems = List.from(_items);
      } else {
        _filteredItems = _items.where((item) {
          return item.name.toLowerCase().contains(query) ||
              item.description.toLowerCase().contains(query);
        }).toList();
      }
    });
  }

  Future<void> _loadData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? itemsString = prefs.getString('items_list');

    if (itemsString != null) {
      List<dynamic> itemsMap = json.decode(itemsString);
      setState(() {
        _items = itemsMap.map((item) => ItemModel.fromMap(item)).toList();
        _filteredItems = List.from(_items); // [BARU] Sinkronkan filtered list
      });
    } else {
      setState(() {
        _items = List.from(_dummyItems);
        _filteredItems = List.from(_items); // [BARU] Sinkronkan filtered list
      });
      await _saveData();
    }
  }

  Future<void> _saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<Map<String, dynamic>> itemsMap =
        _items.map((item) => item.toMap()).toList();
    String itemsString = json.encode(itemsMap);
    await prefs.setString('items_list', itemsString);
  }

  void _showAddDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Tambah Item Baru"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _nameController,
                decoration: InputDecoration(labelText: 'Nama Item'),
              ),
              TextField(
                controller: _descController,
                decoration: InputDecoration(labelText: 'Deskripsi Item'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                _nameController.clear();
                _descController.clear();
                Navigator.pop(context);
              },
              child: Text('Batal'),
            ),
            ElevatedButton(onPressed: _addItem, child: Text('Simpan')),
          ],
        );
      },
    );
  }

  Future<void> _addItem() async {
    if (_nameController.text.isEmpty || _descController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Nama dan deskripsi tidak boleh kosong')),
      );
      return;
    }

    int newId = _items.isNotEmpty ? _items.last.id + 1 : 1;
    ItemModel newItem = ItemModel(
      id: newId,
      name: _nameController.text,
      description: _descController.text,
    );

    setState(() {
      _items.add(newItem);
      _onSearchChanged(); // [BARU] Refresh filtered list setelah tambah item
    });

    await _saveData();
    _nameController.clear();
    _descController.clear();

    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Item berhasil ditambahkan')),
    );
  }

  // [FIX] Dipindahkan ke dalam class agar bisa akses _items dan setState
  Future<void> _deleteItem(int id) async {
    setState(() {
      _items.removeWhere((item) => item.id == id);
      _filteredItems.removeWhere((item) => item.id == id); // [BARU] Hapus juga dari filtered list
    });

    await _saveData();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Item berhasil dihapus')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Daftar Item'), centerTitle: true),
      body: Column(
        children: [
          // [BARU] Search bar
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Cari item...',
                prefixIcon: Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                        },
                      )
                    : null,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 16, vertical: 0),
              ),
            ),
          ),

          // [BARU] Info jumlah hasil pencarian
          if (_searchController.text.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  '${_filteredItems.length} item ditemukan',
                  style: TextStyle(color: Colors.grey[600], fontSize: 13),
                ),
              ),
            ),

          // List item
          Expanded(
            child: _filteredItems.isEmpty
                ? Center(
                    child: Text(
                      _searchController.text.isNotEmpty
                          ? 'Item tidak ditemukan.' // [BARU] Pesan saat search tidak ada hasil
                          : 'Tidak ada data. Tambahkan item baru.',
                    ),
                  )
                : ListView.builder(
                    itemCount: _filteredItems.length,
                    itemBuilder: (context, index) {
                      final item = _filteredItems[index];
                      return Card(
                        margin:
                            EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: Colors.blue,
                            child: Text(
                              '${item.id}',
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                          title: Text(
                            item.name,
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(item.description),
                          trailing: IconButton(
                            icon: Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _deleteItem(item.id), // [FIX] Memanggil method dalam class
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddDialog,
        child: Icon(Icons.add),
        tooltip: 'Tambah Item',
      ),
    );
  }
}